# Spring Website Refresh

Shared files for the spring refresh of the studio website.

- **Design/**: palette, logo concept and the home screen wireframe
- **Docs/**: roadmap, meeting notes and the budget
- **Photos/**: candidate header images

Questions go in the weekly meeting notes.
