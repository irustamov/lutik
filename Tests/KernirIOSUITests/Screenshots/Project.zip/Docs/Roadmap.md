# Roadmap

## March
- Kickoff and brief
- Palette and logo concept

## April
- Wireframes for all five pages
- First round of copy

## May
- Build and review
- Launch
