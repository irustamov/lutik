# Weekly meeting notes

## Week 3
- The palette is approved; the coral accent stays.
- Two header photos are in the running: Coastline and Mountain Lake.
- Next: the card layout on the home page.

## Week 2
- Reviewed three logo concepts and picked the circular one.
- The wireframe needs a smaller hero on phones.
