# Field Notes

A small SwiftUI app for keeping notes while you are out walking.

## Build

Open the folder in Xcode 26 and run the FieldNotes scheme. No packages, no setup.

## Layout

- `src/` the app's Swift code
- `assets/` the app icon and logo
- `cover.png` the cover image for the project page
- `brief.pdf` the one-page project brief

Released under the MIT License, see LICENSE.
