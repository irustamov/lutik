import Foundation

extension URL {
    /// notes.json in the app's Documents folder.
    static var notesFile: URL {
        URL.documentsDirectory.appending(path: "notes.json")
    }
}

extension String {
    /// The first line, for list titles and share sheets.
    var firstLine: String {
        split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: true)
            .first.map(String.init) ?? ""
    }

    /// Word count, as shown under a note.
    var wordCount: Int {
        var count = 0
        enumerateSubstrings(in: startIndex..., options: [.byWords, .localized]) { _, _, _, _ in
            count += 1
        }
        return count
    }
}

extension Date {
    /// "Morning", "Afternoon" or "Evening", used to group notes by time of day.
    var partOfDay: String {
        switch Calendar.current.component(.hour, from: self) {
        case 5..<12: "Morning"
        case 12..<18: "Afternoon"
        default: "Evening"
        }
    }
}
