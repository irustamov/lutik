import SwiftUI

/// Field Notes: a small app for keeping notes while you are out walking.
@main
struct FieldNotesApp: App {
    @State private var store = NoteStore()

    var body: some Scene {
        WindowGroup {
            NoteList()
                .environment(store)
        }
    }
}

@Observable
final class NoteStore {
    private(set) var notes: [Note] = []

    func add(_ text: String, at place: String?) {
        let note = Note(text: text, place: place, created: .now)
        notes.insert(note, at: 0)
        save()
    }

    func remove(_ note: Note) {
        notes.removeAll { $0.id == note.id }
        save()
    }

    func notes(matching query: String) -> [Note] {
        guard !query.isEmpty else { return notes }
        return notes.filter { $0.text.localizedStandardContains(query) }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(notes)
            try data.write(to: .notesFile, options: .atomic)
        } catch {
            print("Could not save notes: \(error.localizedDescription)")
        }
    }
}

struct Note: Identifiable, Codable, Hashable {
    var id = UUID()
    var text: String
    var place: String?
    var created: Date
}

struct NoteList: View {
    @Environment(NoteStore.self) private var store
    @State private var query = ""
    @State private var draft = ""

    var body: some View {
        NavigationStack {
            List {
                Section {
                    TextField("New note", text: $draft)
                        .onSubmit(addDraft)
                }
                Section("Notes") {
                    ForEach(store.notes(matching: query)) { note in
                        NoteRow(note: note)
                            .swipeActions {
                                Button("Delete", role: .destructive) { store.remove(note) }
                            }
                    }
                }
            }
            .navigationTitle("Field Notes")
            .searchable(text: $query)
        }
    }

    private func addDraft() {
        let text = draft.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        store.add(text, at: nil)
        draft = ""
    }
}

struct NoteRow: View {
    let note: Note

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(note.text)
                .lineLimit(3)
            HStack {
                Text(note.created, format: .relative(presentation: .named))
                if let place = note.place {
                    Text("·")
                    Text(place)
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding(.vertical, 2)
    }
}
