Nested __MACOSX fixture.
