Mac junk fixture.
