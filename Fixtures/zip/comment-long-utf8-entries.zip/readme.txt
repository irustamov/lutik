Long UTF-8 archive comment, entries with their own comments.
