Archive with a comment.
