A .docx is a zip, but not an archive.
