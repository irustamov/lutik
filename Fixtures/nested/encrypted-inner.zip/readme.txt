The inner archive has a password.
