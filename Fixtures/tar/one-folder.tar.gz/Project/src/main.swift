print("Hello, Kernir!")
